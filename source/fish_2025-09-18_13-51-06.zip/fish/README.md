# Godot WebXR Template

This is a template for quickly getting started with WebXR projects in Godot. It is based off the original tutorial ([blogpost](https://www.snopekgames.com/tutorial/2020/how-make-vr-game-webxr-godot), [video](https://www.youtube.com/watch?v=vWP7Ti2nhKE)) by [David Snopek](https://github.com/dsnopek), who was responsible for bringing WebXR support to Godot in the first place! Essentially this is just the end result of running through the original tutorial up to the point where the project gets exported. Make sure you have Godot's HTML5 export template downloaded!
